# -*- coding: utf-8 -*-
"""Ñackson Store: preparar portadas de Películas sin alterar productos ni otros medios.
Ejecutar: py preparar_portadas.py "C:\\ruta\\al\\2° Front-End"
"""
from pathlib import Path
import csv, os, shutil, sys, unicodedata, re

BASE=Path(__file__).resolve().parent
if len(sys.argv)<2:
    print('USO: py preparar_portadas.py "C:\\ruta\\Ventas_Discos_Web\\2° Front-End"')
    sys.exit(1)
FRONT=Path(sys.argv[1].strip('"')).expanduser().resolve()
DEST=FRONT/'public'/'productos'/'peliculas'
if not (FRONT/'public').is_dir():
    print('ERROR: no se encontro public/ en el frontend indicado:',FRONT)
    sys.exit(1)
DEST.mkdir(parents=True,exist_ok=True)
def esc(s): return "'"+s.replace("'","''")+"'"
def base(s):
 s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
 return re.sub(r'[^a-z0-9]+','-',s).strip('-')[:75]
registros=list(csv.DictReader(open(BASE/'MAPEO_PORTADAS_PELICULAS.csv',encoding='utf-8-sig')))
queries=[]; faltan=[]
for r in registros:
    stem=base(r['nombre_exactamente_en_mysql'])
    origen=next((BASE/'portadas_origen'/f'{stem}{e}' for e in ['.jpg','.jpeg','.png','.webp'] if (BASE/'portadas_origen'/f'{stem}{e}').is_file()),None)
    if not origen:
        faltan.append(r['nombre_exactamente_en_mysql']);continue
    salida=DEST/(stem+origen.suffix.lower())
    shutil.copy2(origen,salida)
    url='/productos/peliculas/'+salida.name
    queries.append(f"UPDATE producto SET imagen_url={esc(url)} WHERE categoria='SERIES_PELICULAS_ANIME' AND genero='Película' AND nombre={esc(r['nombre_exactamente_en_mysql'])};")
    print('LISTA:',salida.name)
sql=BASE/'ACTUALIZAR_PORTADAS_PELICULAS.sql'
sql.write_text('-- Ejecutar en phpMyAdmin, base db_catalog.\n-- Solo actualiza imagen_url en productos encontrados; no altera precio, stock ni otras categorías.\nUSE `db_catalog`;\nSET NAMES utf8mb4;\n'+ '\n'.join(queries)+'\n',encoding='utf-8')
print(f'\nPortadas copiadas: {len(queries)} / {len(registros)}')
print(f'SQL generado: {sql}')
if faltan:
    print('Aun faltan:')
    for x in faltan: print(' -',x)
if not queries: print('No hay imagenes aun: el SQL no hace cambios.')
