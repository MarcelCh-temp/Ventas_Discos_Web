-- ÑACKSON STORE — CATÁLOGO DE PRUEBA CON SERIES CONSERVADA.
-- IMPORTANTE: precios y stock de demostración, NO confirmados por el usuario.
-- IMPORTANTE: no incluye fotos (imagen_url NULL). Respaldar db_catalog antes de importar.
-- Importar en phpMyAdmin seleccionando la base db_catalog (o ejecutar directamente con USE).
-- No altera los productos existentes ni elimina categorías del backend.
-- 125 títulos en CSV; SQL excluye artículos con preventa o publicación incierta.
-- El backend utiliza la categoría técnica compartida SERIES_PELICULAS_ANIME.
-- SeriesPage.tsx filtra genero='Serie'; por eso este SQL utiliza exactamente 'Serie'.
-- Películas usa genero='Película'; Anime usa genero='Anime'; Blu-ray filtra formato='Blu-ray'.
-- IMPORTANTE: al compartir categoría técnica, Blu-ray y Películas pueden solaparse en filtros.
USE `db_catalog`;
SET NAMES utf8mb4;

CREATE TEMPORARY TABLE tmp_nackson_lote (
 nombre varchar(150) NOT NULL,
 categoria varchar(60) NOT NULL,
 descripcion varchar(2000),
 formato varchar(60) NOT NULL,
 genero varchar(60) NOT NULL,
 plataforma varchar(60),
 precio_base decimal(12,2) NOT NULL,
 stock_actual int NOT NULL,
 PRIMARY KEY(nombre,categoria)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO tmp_nackson_lote (nombre,categoria,descripcion,formato,genero,plataforma,precio_base,stock_actual)
VALUES
('Shogun Serie Completa Clásica 4 DVD','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Serie de TV Paramount 39 Episodios Clásicos','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Ben 10 Classic - Colección Completa Warner Bros (DVD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,18990,10),
('Kim Possible - La Serie Animada Clásica','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,18990,10),
('Los Archivos Místicos de Dantalian - La Serie Completa','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,18990,10),
('Iron Man - Serie Animada Completa de 1994 (3 DVD, usado)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Lo Que el Viento Se Llevó - DVD Original','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,14990,10),
('Viaje al Séptimo Planeta / Guerra de Mundos - DVD','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,14990,10),
('Qué Bello Es Vivir - Frank Capra - Cinehome','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,14990,10),
('La Dimensión Desconocida - Serie de TV Paramount Completa','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Spartacus War of the Damned - Temporada 3 (4 DVD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Área 12 - Serie de TV Español Latino (6 DVD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Futurama - Serie Original en DVD','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('The L Word - Serie Completa en DVD','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Gossip Girl - The Complete Series (DVD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Series. Precio/stock de prueba, edición por verificar.','DVD','Serie',NULL,21990,10),
('Avengers: Infinity War (Marvel)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('El Gran Pez (Tim Burton)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Operación Red Sparrow','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Una Mujer Fantástica (película chilena)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Bichos: Una Aventura en Miniatura (Disney)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Horton y el Mundo de los Quién','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Todo Sobre Mi Madre (Pedro Almodóvar)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Se Levanta el Viento (Ghibli Miyazaki)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Kill Bill Volumen 2 (Tarantino)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('¿Qué He Hecho Yo Para Merecer Esto? (Pedro Almodóvar)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Up: Una Aventura de Altura (Disney Pixar)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('El Recuerdo de Marnie (Ghibli Miyazaki)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('El Castillo en el Cielo (Ghibli Miyazaki)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Recuerdos del Ayer (Ghibli)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('África Mía','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('101 Dálmatas (Disney)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Anastasia','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('La Bella Durmiente (Disney)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Breaking Bad - Temporada 3','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,18990,10),
('Mi Bella Dama (My Fair Lady)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Películas. Precio/stock de prueba, edición por verificar.','DVD','Película',NULL,14990,12),
('Outlanders (Blu-ray)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Ulysse 31 (Blu-ray Custom)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Hajime no Ippo: New Challenger (Blu-ray Custom)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Vampire Princess Miyu - Blu-ray Box','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Arrow Emblem Grand Prix no Taka (Blu-ray Box Custom)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Urotsukidoji: The Perfect Collection (SD on BD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Jet Marte (SD on BD Blu-ray)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Patlabor EZY File-1 (Blu-ray)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Robotech II: Los Centinelas (SD on BD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Scarlet (Blu-ray)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','Blu-ray','Anime',NULL,24990,10),
('Infinite Stratos - Original Soundtrack','MUSICA','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','CD','Anime',NULL,16990,10),
('Psychic Force - Original Video Animation Mini Album','MUSICA','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','CD','Anime',NULL,16990,10),
('Fullmetal Alchemist - Temporadas 1 y 2 + Películas + OVA (DVD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','DVD','Anime',NULL,24990,10),
('Bleach - Serie TV Vol. 1-366 + Películas + Especiales (DVD)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','DVD','Anime',NULL,24990,10),
('Sonic X','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','DVD','Anime',NULL,24990,10),
('Steins;Gate - Serie Completa + Película + OVA','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','DVD','Anime',NULL,24990,10),
('Puella Magi Madoka Magica','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','DVD','Anime',NULL,24990,10),
('Memories','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','DVD','Anime',NULL,24990,10),
('Ghost in the Shell','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Anime. Precio/stock de prueba, edición por verificar.','DVD','Anime',NULL,24990,10),
('El Club de la Pelea','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Hombres de Negro 1 y 2','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Ant-Man and The Wasp','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Asesinato en el Expreso de Oriente','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Tan Fuerte Tan Cerca','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('La Cosa (The Thing)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('The Truman Show','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Christopher Robin: Un Reencuentro Inolvidable','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('La Noche Más Oscura (Zero Dark Thirty)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('¿Quién Engañó a Roger Rabbit?','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Dúo Día de la Independencia / Contraataque','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Constantine','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Linterna Verde','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Superman IV','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Assassin’s Creed','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Aquaman (Edición Steelbook)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Seven: Los Siete Pecados Capitales','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Tiburón','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Rambo 5 Film Collection','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Corazón de Caballero','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('John Wick Capítulos 1-4','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Dúo Alien vs Depredador 1 y 2','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Tenet (Nolan)','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Hombres de Negro','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('Una Carta para Momo','SERIES_PELICULAS_ANIME','Producto de demostración Ñackson Store, sección Blu-ray. Precio/stock de prueba, edición por verificar.','Blu-ray','Película',NULL,19990,10),
('The Settlers: Construye Tu Imperio (PC)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PC',39990,10),
('Twisted Lands Origin 4 Pack Bonus Edition (PC DVD)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PC',39990,10),
('StarCraft: Brood War Expansion Set (PC físico)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PC',39990,10),
('Samantha Swift and the Golden Touch (PC)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PC',39990,10),
('Disciples III (PC físico)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PC',39990,10),
('Red Dead Redemption 2 (PS4)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS4',39990,10),
('Elden Ring Tarnished Edition (Switch 2)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','Switch 2',39990,10),
('Pragmata (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Silent Hill: Townfall (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Coffee Talk Tokyo (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Corpse Party 2: Darkness Distortion (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Crisis Core: Final Fantasy VII Reunion (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Culdcept The First Saturn Tribute (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Cyberpunk 2077: Ultimate Edition (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Dead Cells: Return to Castlevania Edition (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Death Stranding Director’s Cut (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Death Stranding 2: On The Beach (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Demons Night Fever (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Demon’s Souls (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Diablo IV (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Digimon Story Time Stranger (Europeo, PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Dragon Ball Xenoverse 2 (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Final Fantasy Tactics: The Ivalice Chronicles (PS5)','VIDEOJUEGOS','Producto de demostración Ñackson Store, sección Videojuegos. Precio/stock de prueba, edición por verificar.','Físico','Videojuego','PS5',39990,10),
('Audífonos cerrados para estudio','ACCESORIOS','Producto de demostración Ñackson Store, sección Accesorios. Precio/stock de prueba, edición por verificar.','Físico','Audio / Tecnología',NULL,29990,8),
('Monitor de estudio activo KRK V8 Series Five 8 pulgadas 455 W','ACCESORIOS','Producto de demostración Ñackson Store, sección Accesorios. Precio/stock de prueba, edición por verificar.','Físico','Audio / Tecnología',NULL,29990,8),
('Amplificador de monitoreo personal Behringer P1','ACCESORIOS','Producto de demostración Ñackson Store, sección Accesorios. Precio/stock de prueba, edición por verificar.','Físico','Audio / Tecnología',NULL,29990,8),
('Amplificador de auriculares Behringer AMP800 V2 de 4 canales','ACCESORIOS','Producto de demostración Ñackson Store, sección Accesorios. Precio/stock de prueba, edición por verificar.','Físico','Audio / Tecnología',NULL,29990,8),
('Llavero / Keychain - One Piece','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Estuche Nintendo Switch Poké Ball','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Charizard EX Special Collection - Español','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Mega Evolution (Base Set) Booster Bundle - Inglés','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Mega Evolution Chaos Rising Elite Trainer Box - Inglés','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('One Piece - Zoro Viñetas - Polera','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Kiki Delivery Service - Jiji - Polera','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Slam Dunk - Collage - Polera','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Destapador Halcón Milenario','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Botella Termo Hogwarts 530 ml - Harry Potter','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Taza Mr. Meeseeks - Rick y Morty','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10),
('Orb: On the Movements of the Earth - Bag Charm','MERCHANDISING','Producto de demostración Ñackson Store, sección Merchandising. Precio/stock de prueba, edición por verificar.','Físico','Coleccionable',NULL,12990,10);

START TRANSACTION;
INSERT INTO producto (categoria,descripcion,estado,formato,genero,imagen_url,nombre,plataforma,precio_base)
SELECT s.categoria,s.descripcion,'ACTIVO',s.formato,s.genero,NULL,s.nombre,s.plataforma,s.precio_base
FROM tmp_nackson_lote s
WHERE NOT EXISTS (SELECT 1 FROM producto p WHERE p.nombre=s.nombre AND p.categoria=s.categoria);

INSERT INTO inventario (product_id,stock_actual,umbral_critico)
SELECT p.id,s.stock_actual,5 FROM tmp_nackson_lote s
JOIN producto p ON p.nombre=s.nombre AND p.categoria=s.categoria
WHERE NOT EXISTS (SELECT 1 FROM inventario i WHERE i.product_id=p.id);
COMMIT;

SELECT COUNT(*) AS productos_del_lote FROM tmp_nackson_lote;
SELECT genero, formato, COUNT(*) AS productos FROM tmp_nackson_lote
WHERE categoria='SERIES_PELICULAS_ANIME' GROUP BY genero,formato ORDER BY genero,formato;
DROP TEMPORARY TABLE tmp_nackson_lote;
